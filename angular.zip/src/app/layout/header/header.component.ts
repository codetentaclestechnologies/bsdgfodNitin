import { Component, OnDestroy, OnInit } from '@angular/core';
import { GlobalService } from 'src/app/core/services/global.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  isConnected = false;
  address: any;
  tronweb: any;
  contractAddress = environment.bsgAddr;
  contractInfo: any;
  runTime: any;
  depositCountDown = 0;

  constructor(private cs: GlobalService) {
    this.tronweb = cs.tronweb;
  }


  ngOnInit(): void {
    this.connect();
  }
  async connect() {
    await this.getaccount();
  }

  async getaccount() {
    await this.cs
      .connectContract()
      .then(async (balance) => {
        this.address = balance;
        console.log(this.tronweb);

        this.isConnected = true;
        localStorage.setItem('address', this.address);

        this.startTime();
      })
      .catch((error) => (this.isConnected = error));
  }

  async startTime() {
    try {
      this.runTime = await this.cs.startTime();
   
    } catch (e) {
      console.log(e);
    }
  }

  async depositeCountDown() {
    try {
      let OrderLength = await this.cs.getOrderLength(this.address);
      if(OrderLength>0){
        let unfreeze = await this.cs.orderInfos(this.address,OrderLength)
        this.depositCountDown  = parseInt(unfreeze)*1000
      }else {
        this.depositCountDown = 0
      }
    } catch (e) {
      console.log(e);
    }
  }

}
