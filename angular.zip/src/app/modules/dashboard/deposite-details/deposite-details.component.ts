import { Component, OnInit } from '@angular/core';
import { GlobalService } from 'src/app/core/services/global.service';
import $ from 'jquery';
@Component({
  selector: 'app-deposite-details',
  templateUrl: './deposite-details.component.html',
  styleUrls: ['./deposite-details.component.scss'],
})
export class DepositeDetailsComponent implements OnInit {
  constructor(private cs: GlobalService) {}
  isShowStatus = false
  async ngOnInit() {
    await this.cs.connectContract();
  }

  async updateOrders() {
    let length = await this.cs.getDepositeDetailOrederLength(
      localStorage.getItem('address')
    );
    for (let i = length - 1; i >= 0; i--) {
      var { amount, start, unfreeze, isUnfreezed } = await this.cs.orderInfos(
        localStorage.getItem('address'),
        i
      );
      var depositHtml = '<tr>';
      var startTS = parseInt(start) * 1000;

      // 存款金额
      var dAmt = await this.cs.fromSun(amount);
      depositHtml =
        depositHtml +
        "<td><span class='DepC2 DepCZ1'>$" +
        dAmt +
        '</span></td>';

      // 存款日期
      var startDate = this.getDate(startTS);
      depositHtml =
        depositHtml + "<td><span class='DepC3'>" + startDate + '</span></td>';

      // 解冻日期
      var unfreezeTS = parseInt(unfreeze) * 1000;
      var unfreezeDate = this.getDate(unfreezeTS);
      depositHtml =
        depositHtml +
        "<td><span class='DepC4'>" +
        unfreezeDate +
        '</span></td>';

      // 周期收益
      var income = this.cs.fromSun((parseInt(amount) * 225) / 1000);
      depositHtml =
        depositHtml +
        "<td><span class='DepC4 DepCZ2'>$" +
        income +
        '</span></td>';

      // 订单状态
      var date = new Date();
      var timeNow = date.getTime();
      var status = '';
      var className = '';
      if (timeNow < unfreezeTS) {
        status = 'Freezing';
        className = 'DepC1';
      } else {
        if (isUnfreezed) {
          status = 'Completed';
          className = 'DepC6';
        } else {
          status = 'Unbonded';
          className = 'DepC3';
        }
      }
      depositHtml =
        depositHtml +
        "<td><span class='" +
        className +
        "'>" +
        status +
        '</span></td>';
      depositHtml = depositHtml + '</tr>';
      $('.DepTab').append(depositHtml);
    }
  }
  isShowStatusFn(){
    this.isShowStatus = this.isShowStatus==true ? this.isShowStatus=false : this.isShowStatus= true
  }
  getDate(timstamp: any) {
    var date = new Date(timstamp);
    var year = date.getFullYear(); // 获取完整的年份(4位,1970)
    var month = date.getMonth() + 1; // 获取月份(0-11,0代表1月,用的时候记得加上1)
    var day = date.getDate(); // 获取日(1-31)
    var hour = date.getHours(); // 获取小时数(0-23)
    var minute = date.getMinutes(); // 获取分钟数(0-59)
    var second = date.getSeconds(); // 获取秒数(0-59)
    var forMatDate =
      year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    return forMatDate;
  }
}
