export const environment = {
  production: true,
  bsgAddr : 'TSQo8Nn7muPZ78CAjhGCobUnd3m6vLKnNw',
  usdtAddr : 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
  refererDefault : 'TJizNWpUkhJtLShTj4XKNwJVyheqH35cRx',
  zeroAddr : 'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb'
};
